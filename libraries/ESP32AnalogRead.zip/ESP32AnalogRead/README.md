# ESP32AnalogRead
Load the calibration data and provide a calibrated analog read

# Supported Versions
- ESP32
- ESP32-S2
- ESP32-S3

# Documentation by Doxygen

[ESP32AnalogRead Doxygen](https://madhephaestus.github.io/ESP32AnalogRead/files.html)

